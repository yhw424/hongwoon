# PROMPTS.md

## 과제명
논문 Fig. 5 기반 Lorenz Attractor Reservoir Computing 시뮬레이션 구현

## 작성 목적
본 문서는 과제 수행 과정에서 ChatGPT에 입력한 프롬프트 로그를 정리한 파일이다.  
교수님 제출 요구사항 중 “프롬프트 로그”에 해당하며, 보고서 본문이 아니라 **프롬프트 입력 기록 및 사용 목적 정리**를 목적으로 한다.

## 사용 논문
- Sanghyeon Choi et al., “3D-integrated multilayered physical reservoir array for learning and forecasting time-series information,” Nature Communications, 2024.
- 구현 대상: Fig. 5, Physical reservoir computing for prediction of time-dependent Lorenz attractor.

---

## Prompt Log

### Prompt 01
```text
논문에 나온 시뮬레이션을 그대로 따라해보고 싶어. 파이썬 코드로 작성해줘
```

#### 목적
논문 그림에 제시된 Lorenz attractor prediction 시뮬레이션을 Python 코드로 구현하기 위해 기본 코드를 요청하였다.

#### 결과 요약
- Lorenz equation 기반 x, y, z trajectory 생성 코드 작성
- reservoir computing 구조를 Python으로 모사
- linear regression readout을 이용한 다음 timestep 예측 구조 제안
- NMSE 계산 및 그래프 출력 코드 작성

---

### Prompt 02
```text
이 부분이 조금 다르네
```

#### 목적
생성된 NMSE 비교 plot이 논문 Fig. 5f와 다르게 나타나는 문제를 지적하고, 논문 그림과 더 유사하게 수정하도록 요청하였다.

#### 결과 요약
- 논문 Fig. 5f의 y축이 `NMSE × 10^-3` 단위임을 확인
- 기존 코드에서 1-reservoir 조건이 논문 비교와 다르게 설정되었음을 검토
- raw input x, y, z가 readout feature에 직접 들어가는 shortcut 문제를 지적
- reservoir states만 readout에 사용하도록 코드 수정 방향 제시
- Fig. 5f 스타일의 NMSE bar plot 함수 수정

---

### Prompt 03
```text
논문을 보내줄게 논문 확인하고, Fig.5 시뮬레이션을 파이썬 코드로 결과 동일하게 작성
```

#### 목적
논문 PDF를 업로드한 뒤, 실제 논문 본문과 Methods를 확인하여 Fig. 5 시뮬레이션을 논문 조건에 맞게 다시 구현하도록 요청하였다.

#### 첨부 자료
```text
3. 연구관련논문(1).pdf
```

#### 결과 요약
- 논문 본문과 Methods에서 Fig. 5 구현 조건 확인
- Lorenz equation parameter 확인:
  - α = 10
  - β = 28
  - γ = 8/3
- Lorenz x, y, z component를 0–1.8 V 범위로 정규화해야 함을 확인
- reservoir당 100개 memristor node 사용
- 3-reservoir 구조에서는 총 300개 reservoir state 사용
- 초기 100 timestep은 initialization으로 사용
- 1400 timestep까지 linear regression으로 weight 학습
- timestep t의 reservoir state로 timestep t+1의 behavior 예측
- 논문 보고 NMSE 확인:
  - multiple reservoirs 평균 NMSE ≈ 2.62 × 10^-4
  - single reservoir 평균 NMSE ≈ 1.35 × 10^-3

#### 중요 검토 내용
논문에는 실제 100개 memristor의 reservoir current response matrix가 제공되어 있지 않으므로, 물리 소자 응답까지 완전히 동일한 재현은 불가능하다고 판단하였다.  
따라서 surrogate reservoir model과 Fig. 5 수준의 NMSE calibration을 포함한 구현 방향을 정하였다.

---

### Prompt 04
```text
전체 코드로 작성
```

#### 목적
Fig. 5 재현 과정을 부분 코드가 아니라 하나의 실행 가능한 Python 전체 코드로 작성하도록 요청하였다.

#### 결과 요약
단일 Python 스크립트 형태의 전체 코드가 작성되었다.

주요 구성:
1. Lorenz attractor 생성
2. x, y, z component를 0–1.8 V 범위로 정규화
3. WOx memristor physical reservoir surrogate 모델 정의
4. multiple reservoir state matrix 생성
5. single reservoir state matrix 생성
6. linear regression readout 학습
7. timestep t → timestep t+1 prediction 수행
8. NMSE 계산
9. Fig. 5a, 5b, 5d, 5e, 5f에 해당하는 그래프 저장

출력 파일:
```text
fig5_outputs/fig5a_lorenz_3d.png
fig5_outputs/fig5b_deconvoluted_timeseries.png
fig5_outputs/fig5d_prediction_3d.png
fig5_outputs/fig5e_timeseries_prediction.png
fig5_outputs/fig5f_nmse.png
```

---

### Prompt 05
```text
지금까지 대화내용을 prompt.md 파일로 출력
```

#### 목적
지금까지의 대화 흐름을 Markdown 파일로 정리하도록 요청하였다.

#### 결과 요약
초기에는 대화 요약, 논문 조건, 코드, 검증 메모까지 포함한 `prompt.md` 파일이 작성되었다.  
그러나 이후 교수님 요구사항을 확인한 결과, 이 파일은 엄밀한 의미의 “프롬프트 로그”라기보다 “대화 요약 + 구현 설명 + 코드 기록”에 가까운 형식임을 확인하였다.

---

### Prompt 06
```text
과제를 이런 식으로 교수님이 말씀하셨는데, 너가 작성해준 파일이랑 의도가 다른 것 같아
```

#### 목적
교수님이 요구한 제출물의 의도를 다시 확인하고, 기존 prompt.md 파일이 과제 요구사항과 맞는지 검토하도록 요청하였다.

#### 결과 요약
기존 `prompt.md`는 과제용 PROMPTS.md의 의도와 다르다고 판단하였다.

교수님 요구사항 해석:
1. 보고서
   - 순차적 구현 매뉴얼 포함
   - 프롬프트 입력 내용 포함
   - 구현 절차, 실행 방법, 결과, 한계 등을 정리하는 본문 보고서

2. 프롬프트 로그
   - 본인이 ChatGPT에 입력한 프롬프트를 기록한 `PROMPTS.md`
   - 실제 입력 프롬프트 중심
   - 각 프롬프트의 목적과 산출 결과를 간단히 정리

이에 따라 본 파일을 과제 제출용 `PROMPTS.md` 형식으로 다시 작성하였다.

---

## 전체 프롬프트 사용 흐름 요약

| 단계 | 프롬프트 목적 | 산출물 |
|---|---|---|
| 1 | 논문 시뮬레이션 기본 코드 요청 | Lorenz RC 기본 Python 코드 |
| 2 | NMSE plot 차이 수정 요청 | 논문 Fig. 5f 형식 반영 |
| 3 | 논문 PDF 기반 재검토 요청 | 논문 Methods 조건 확인 |
| 4 | 전체 코드 요청 | 실행 가능한 단일 Python 코드 |
| 5 | 대화 내용 Markdown 출력 요청 | 초기 prompt.md 생성 |
| 6 | 교수님 요구사항과 파일 의도 비교 | 제출용 PROMPTS.md 재작성 |

---

## 구현 과정에서 확인한 핵심 한계

논문은 실제 WOx memristor array에서 측정한 reservoir state/current response를 사용하지만, PDF 본문에는 해당 원시 데이터가 포함되어 있지 않다.

따라서 현재 구현은 다음 성격을 가진다.

```text
논문 Methods 기반 재현 + surrogate physical reservoir model + Fig. 5 수준의 결과 보정
```

완전한 원 논문 실험 데이터 재현을 위해서는 다음 중 하나가 필요하다.

```text
1. 논문 저자 제공 raw reservoir state matrix
2. Supplementary code/data
3. 실제 WOx memristor pulse response 측정 데이터
4. Supplementary Fig. 28, 31, 32 기반의 정량 fitting model
```

---

## 제출 시 파일명 권장

교수님이 파일명을 명시한 경우 다음 이름을 사용하는 것이 적절하다.

```text
PROMPTS.md
```

기존 `prompt.md`보다 `PROMPTS.md`가 요구사항에 더 직접적으로 부합한다.
