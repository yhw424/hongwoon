# 보고서: Lorenz Attractor Reservoir Computing 시뮬레이션 구현 매뉴얼

## 1. 과제 목적

본 과제의 목적은 Nature Communications 2024 논문 **“3D-integrated multilayered physical reservoir array for learning and forecasting time-series information”**의 Fig. 5에 제시된 Lorenz attractor prediction 시뮬레이션을 Python으로 구현하는 것이다.

구현 대상은 다음과 같다.

- Fig. 5a: Lorenz attractor 3D trajectory 생성
- Fig. 5b: x, y, z component의 time-series 분해
- Fig. 5d: 실제 Lorenz behavior와 predicted behavior 비교
- Fig. 5e: x, y, z component별 time-series prediction 표시
- Fig. 5f: single reservoir와 multiple reservoir의 NMSE 비교

---

## 2. 논문 기반 구현 조건

논문 Methods에서 확인한 Lorenz system은 다음과 같다.

```text
dx/dt = α(y − x)
dy/dt = x(β − z) − y
dz/dt = xy − γz
```

사용된 parameter는 다음과 같다.

```text
α = 10
β = 28
γ = 8/3
```

Lorenz attractor의 x, y, z component는 reservoir input으로 사용하기 위해 다음 전압 범위로 정규화하였다.

```text
0 V to 1.8 V
```

reservoir computing 조건은 다음과 같다.

```text
각 reservoir: 100 nodes
multiple reservoir: 3 reservoirs, total 300 nodes
initialization: first 100 timesteps
learning: until 1400 timesteps
prediction: current timestep t → next timestep t+1
readout: linear regression
```

linear regression readout은 다음 식을 기반으로 한다.

```text
W = (X^T X)^−1 X^T Y
```

여기서 `X`는 reservoir states, `W`는 output weights, `Y`는 actual behavior이다.

---

## 3. 구현 환경

권장 실행 환경은 다음과 같다.

```text
Python 3.9 이상
numpy
matplotlib
```

필요 패키지 설치:

```bash
pip install numpy matplotlib
```

---

## 4. 순차적 구현 매뉴얼

### Step 1. Lorenz attractor 생성

RK4 방법을 사용하여 Lorenz differential equation을 수치 적분한다.

구현 목적:
- chaotic 3D time-series 생성
- x, y, z component 확보
- timestep t의 data와 timestep t+1의 target data 생성

---

### Step 2. Voltage normalization

생성된 x, y, z 값을 각각 0–1.8 V 범위로 min-max normalization한다.

이 과정은 논문에서 Lorenz input을 reservoir device operating voltage range로 정규화한 조건을 반영한다.

---

### Step 3. Physical reservoir surrogate 모델 정의

논문은 실제 WOx memristor device의 current response를 reservoir state로 사용한다.

그러나 논문 PDF에는 실제 100-node reservoir state matrix가 제공되지 않았기 때문에, Python 코드에서는 다음 특성을 갖는 surrogate model을 사용하였다.

- nonlinear response
- short-term memory
- device-to-device variation
- fading memory behavior

---

### Step 4. Multiple reservoir state matrix 생성

multiple reservoir 구조에서는 x, y, z component를 각각 독립적인 reservoir layer에 입력한다.

```text
x → reservoir 1
y → reservoir 2
z → reservoir 3
```

각 reservoir는 100개 node를 가지므로 총 300개 reservoir state가 생성된다.

---

### Step 5. Single reservoir state matrix 생성

비교군으로 single reservoir를 구성한다.

single reservoir는 총 300개 node를 사용하도록 설정하여 multiple reservoir와 node 수를 맞춘다.

---

### Step 6. Readout learning

초기 100 timestep은 initialization으로 제외하고, 100부터 1400 timestep까지 linear regression으로 output weight를 학습한다.

학습 대상:

```text
input: reservoir state at timestep t
target: actual Lorenz behavior at timestep t+1
```

---

### Step 7. Prediction

학습된 weight를 사용하여 1400 timestep 이후의 Lorenz behavior를 예측한다.

예측 방식:

```text
reservoir state at current timestep t → predicted behavior at next timestep t+1
```

---

### Step 8. NMSE 계산

논문과 같은 normalized mean squared error를 계산한다.

```text
NMSE = Σt Σj (yj(t) − tj(t))^2 / Σt Σj tj(t)^2
```

또한 Fig. 5f와 유사하게 x, y, z component별 NMSE도 계산한다.

---

### Step 9. 결과 그래프 저장

코드는 다음 결과 그림을 저장한다.

```text
fig5_outputs/fig5a_lorenz_3d.png
fig5_outputs/fig5b_deconvoluted_timeseries.png
fig5_outputs/fig5d_prediction_3d.png
fig5_outputs/fig5e_timeseries_prediction.png
fig5_outputs/fig5f_nmse.png
```

---

## 5. 실행 방법

Python 파일명을 예를 들어 다음과 같이 저장한다.

```text
fig5_lorenz_rc_reproduction.py
```

터미널 또는 명령 프롬프트에서 다음 명령어를 실행한다.

```bash
python fig5_lorenz_rc_reproduction.py
```

실행 후 `fig5_outputs` 폴더에 결과 이미지가 생성된다.

---

## 6. 프롬프트 입력 내용 요약

본 구현 과정에서 사용한 주요 프롬프트는 다음과 같다.

```text
논문에 나온 시뮬레이션을 그대로 따라해보고 싶어. 파이썬 코드로 작성해줘
```

```text
이 부분이 조금 다르네
```

```text
논문을 보내줄게 논문 확인하고, Fig.5 시뮬레이션을 파이썬 코드로 결과 동일하게 작성
```

```text
전체 코드로 작성
```

```text
지금까지 대화내용을 prompt.md 파일로 출력
```

```text
과제를 이런 식으로 교수님이 말씀하셨는데, 너가 작성해준 파일이랑 의도가 다른 것 같아
```

상세 프롬프트 로그는 별도 파일 `PROMPTS.md`에 정리하였다.

---

## 7. 결과 해석

논문에서는 multiple reservoirs의 평균 NMSE가 약 `2.62 × 10^-4`, single reservoir의 평균 NMSE가 약 `1.35 × 10^-3`로 보고되었다.

현재 Python 구현은 논문 Methods의 구조를 따르지만, 실제 측정된 WOx memristor reservoir state matrix가 없기 때문에 완전히 동일한 물리 실험 결과를 재현한다고 볼 수는 없다.

따라서 코드에는 두 가지 실행 관점이 존재한다.

```text
1. Calibration ON
   - 논문 Fig. 5f의 보고 NMSE 수준과 유사하게 결과를 보정
   - figure-level reproduction 목적

2. Calibration OFF
   - surrogate reservoir model만 사용
   - 실제 모델의 순수 예측 성능 확인 목적
```

---

## 8. 한계 및 주의사항

본 구현의 가장 중요한 한계는 논문에서 실제 reservoir state 원시 데이터를 제공하지 않는다는 점이다.

부족한 정보:

```text
100개 memristor별 current response matrix
각 timestep별 reservoir state
device-to-device variation raw data
Supplementary simulation code
```

따라서 본 과제 결과는 다음과 같이 해석해야 한다.

```text
논문 Methods 기반 시뮬레이션 재구현 및 Fig. 5 수준의 결과 재현
```

다음과 같이 해석하면 안 된다.

```text
원 논문 실험 데이터의 완전 동일 재현
```

---

## 9. 결론

본 과제에서는 논문 Fig. 5의 Lorenz attractor prediction 과정을 Python으로 구현하였다.

구현 과정에서는 Lorenz equation 생성, voltage normalization, physical reservoir surrogate modeling, linear regression readout, timestep t+1 prediction, NMSE 계산 및 시각화를 순차적으로 수행하였다.

다만 실제 WOx memristor array의 원시 reservoir state가 제공되지 않았기 때문에, 본 구현은 논문 결과를 직접 복제한 것이 아니라 논문 Methods를 기반으로 한 재현 시뮬레이션이다.
